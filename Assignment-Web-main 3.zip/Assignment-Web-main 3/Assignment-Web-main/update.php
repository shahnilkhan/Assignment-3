<?php 
    $pageTitle = "Update Page";
    require_once "includes/header.php";
?>
<body>

    <?php require_once "includes/footer.php";?>
</body>