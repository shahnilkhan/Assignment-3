<?php
    define("HOSTNAME","localhost");
    define("USERNAME", "root");
    define("PASSWORD", "");
    define("DB_NAME","phpmysql");
?>